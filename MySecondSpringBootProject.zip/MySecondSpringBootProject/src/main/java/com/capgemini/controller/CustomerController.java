package com.capgemini.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Customer;
import com.capgemini.exceptions.DuplicateMobileNumberException;
import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.MobileNumberDoesNotExistException;
import com.capgemini.service.WalletService;

@RestController
public class CustomerController {

	@Autowired
	WalletService walletServiceImpl;
	
	@RequestMapping(method=RequestMethod.POST, value="/addCustomer/{name}/{mobileNo}/{balance}")
	public Customer createAccount(@PathVariable  String name,@PathVariable String mobileNo,@PathVariable BigDecimal balance ) throws DuplicateMobileNumberException 
	{
		
		return walletServiceImpl.createAccount(name, mobileNo,balance);
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/getBalance/{mobileNo}")
	
	public Customer showBalance(@PathVariable String mobileNo) 
	{
		try {
		return walletServiceImpl.showBalance(mobileNo);}
		catch(MobileNumberDoesNotExistException ex) {
			System.out.println("Mobile Number does not exist");
		}
		return null;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/depositBalance/{mobileNo}/{amount}")
		
		public Customer depositBalance(@PathVariable String mobileNo ,@PathVariable BigDecimal amount) throws MobileNumberDoesNotExistException {
			return walletServiceImpl.depositAmount(mobileNo, amount);
		
		}
		
	
	@RequestMapping(method=RequestMethod.POST, value="/withdrawBalance/{mobileNo}/{amount}")

		public Customer withdrawBalance(@PathVariable String mobileNo ,@PathVariable BigDecimal amount) throws MobileNumberDoesNotExistException, InsufficientBalanceException 
	{
		return walletServiceImpl.withdrawAmount(mobileNo, amount);
		
			 
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/fundTransfer/{sourceMobileNo}/{targetMobileNo}/{amount}")

	public Customer fundTransfer(@PathVariable String sourceMobileNo ,@PathVariable String targetMobileNo ,@PathVariable BigDecimal amount) throws MobileNumberDoesNotExistException, InsufficientBalanceException 
{
		
		return walletServiceImpl.fundTransfer(sourceMobileNo, targetMobileNo, amount);
		
}
	

}




