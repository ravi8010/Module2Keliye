package com.capgemini.exceptions;

public class MobileNumberDoesNotExistException extends Exception {
	private static final long serialVersionUID = 1L;

}
