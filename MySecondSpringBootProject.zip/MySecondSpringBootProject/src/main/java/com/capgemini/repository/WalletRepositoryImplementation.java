package com.capgemini.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Customer;

@Repository
@Transactional
public class WalletRepositoryImplementation implements WalletRepository {
	
	@PersistenceContext
    EntityManager entityManager;

	@Override
	public boolean save(Customer customer) {
		 entityManager.persist(customer);
		 return true;
	}

	@Override
	public Customer findOne(String mobileNumber) {
		Customer customer=entityManager.find(Customer.class, mobileNumber);
		return customer;
	}

	
	@Override
	public boolean updateCustomer(Customer customer) {
		 Customer customer1=entityManager.find(Customer.class, customer.getMobileNumber());
		 customer1.setWallet(customer.getWallet());
		return true;
	}


}
