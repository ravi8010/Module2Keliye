package com.capgemini.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class StudentExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(value=DuplicateIdException.class)
	public final ResponseEntity<Object> handleAllException(DuplicateIdException ex,WebRequest request)
	{			return (new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND));	

	}
	@ExceptionHandler(value=IDDoesNotExistException.class)
	public final ResponseEntity<Object> handleAllException(IDDoesNotExistException ex,WebRequest request)
	{	
		return (new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND));	
	
	}
	@ExceptionHandler(value=ListEmptyException.class)
	public final ResponseEntity<Object> handleAllException( ListEmptyException ex,WebRequest request)
	{	
		return (new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND));	
	
	}
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		return new ResponseEntity<>(ex.getBindingResult().getAllErrors().get(0).getDefaultMessage(),HttpStatus.INTERNAL_SERVER_ERROR); //overide handleMethodArgumentNotValid from source
	}

	
}
