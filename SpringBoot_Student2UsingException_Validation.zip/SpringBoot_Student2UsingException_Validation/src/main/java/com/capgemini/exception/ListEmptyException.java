package com.capgemini.exception;

@SuppressWarnings("serial")
public class ListEmptyException extends RuntimeException {

	public ListEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
