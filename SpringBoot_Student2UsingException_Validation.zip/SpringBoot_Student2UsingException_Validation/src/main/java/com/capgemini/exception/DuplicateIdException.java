package com.capgemini.exception;

@SuppressWarnings("serial")
public class DuplicateIdException extends RuntimeException {

	public DuplicateIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
