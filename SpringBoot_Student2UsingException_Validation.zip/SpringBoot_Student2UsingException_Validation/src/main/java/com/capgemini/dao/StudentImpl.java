package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Student;
@Repository
@Transactional
public class StudentImpl implements IStudent {
@PersistenceContext
EntityManager entityManager;

	public EntityManager getEntityManager() {
	return entityManager;
}

public void setEntityManager(EntityManager entityManager) {
	this.entityManager = entityManager;
}
 


	@Override
	public Student addStudent(Student student) {
		entityManager.persist(student);
		entityManager.flush();
		return student;
	}

	@Override
	public Student findStudent(int id) {
      Student student=entityManager.find(Student.class, id);
      if(student==null)
		return null;
      else
    	  return student;
	}

	@Override
	public Student deleteStudent(int id) {
		Student student=entityManager.find(Student.class,id);
		entityManager.remove(student);
		return student;
	}

	@Override
	public List<Student> getStudents() {
		Query query=entityManager.createNativeQuery("select * from Student1");
		List<Student> list=query.getResultList();
		return list;
	}

	@Override
	public List<Student> getStudentByName(String name) {
		Query query=entityManager.createNativeQuery("select * from Student1 where name=?").setParameter(1, name);

		List<Student> list=query.getResultList();
		return list;
	}

	@Override
	public Student updateStudent(Student student) {
		
		entityManager.merge(student);
		entityManager.flush();
		
		
		return student;
	}

}
