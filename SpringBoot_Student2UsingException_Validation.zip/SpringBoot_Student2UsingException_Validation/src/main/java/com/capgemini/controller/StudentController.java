package com.capgemini.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Student;
import com.capgemini.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	StudentService studentService;

	public StudentService getStudentService() {
		return studentService;
	}

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
	@RequestMapping(value="/addStudent", method=RequestMethod.POST)
	public Student addStudent(@Valid @RequestBody Student student)
	{
		studentService.addStudent(student);
		return student;
	}
	@RequestMapping(value="/deleteStudent/{id}",method=RequestMethod.DELETE)
	public Student deleteStudent(@PathVariable int id)
	{
		return studentService.deleteStudent(id);
		
	}
	@RequestMapping(value="/updateStudent",method=RequestMethod.PUT)
	public Student updateStudent(@RequestBody Student student)
	{
		return studentService.updateStudent(student);
	}
	@RequestMapping(value="/findStudent/{id}",method=RequestMethod.GET)
	public Student findById(@PathVariable int id)
	{
		return studentService.findStudent(id);
	}
	@RequestMapping(value="/getStudents",method=RequestMethod.GET)
	public List<Student> getStudents()
	{
		
		List<Student> list=studentService.getStudents();
		return list;
	}
	@RequestMapping(value="/getStudentByName/{name}",method=RequestMethod.GET)
	List<Student> getStudentByName(@PathVariable String name)
	{
		return studentService.getStudentByName(name);
	}
	
}
